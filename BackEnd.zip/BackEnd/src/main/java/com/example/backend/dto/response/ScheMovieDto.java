package com.example.backend.dto.response;

// TODO: 현재는 Moive data모델이 없어 sche로만 구성됨 추가로 변경해야함.
public interface ScheMovieDto {
    Long getScno();
    Integer getMoviecd();
}
