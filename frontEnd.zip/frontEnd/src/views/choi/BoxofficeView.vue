<template>
  <div>
    <div class="hero common-hero">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="hero-ct">
              <h1>박스오피스 무비차트</h1>
              <ul class="breadcumb">
                <li class="active"><a href="#">Home</a></li>
                <li>
                  <span class="ion-ios-arrow-right"></span> celebrity listing
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- celebrity list section-->
    <div class="page-single">
      <div class="container">
        <div class="row ipad-width2">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <!-- <div class="topbar-filter">
              <p class="pad-change">
                Found <span>1,608 celebrities</span> in total
              </p>
              <label>Sort by:</label>
              <select>
                <option value="popularity">Popularity Descending</option>
                <option value="popularity">Popularity Ascending</option>
                <option value="rating">Rating Descending</option>
                <option value="rating">Rating Ascending</option>
                <option value="date">Release date Descending</option>
                <option value="date">Release date Ascending</option>
              </select>
              <a href="celebritylist.html" class="list"
                ><i class="ion-ios-list-outline active"></i
              ></a>
              <a href="celebritygrid01.html" class="grid"
                ><i class="ion-grid"></i
              ></a>
            </div> -->
            <div class="row">
              <div class="col-md-12">
                <div class="ranking">No.1</div>
              </div>
              <div class="col-md-12">
                <div class="ceb-item-style-2">
                  <img src="images/uploads/ceblist1.jpg" alt="" />
                  <div class="ceb-infor">
                    <h2><a href="celebritysingle.html">아바타: 물의 길</a></h2>
                    <span>Avatar: The Way of Water</span>
                    <p style="margin-top:1%">
                        개봉일: 20221214<br/>
                        오늘까지 총 누적관객수: 2,945,915
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="ranking">No.2</div>
              </div>
              <div class="col-md-12">
                <div class="ceb-item-style-2">
                  <img src="images/uploads/ceblist2.jpg" alt="" />
                  <div class="ceb-infor">
                    <h2><a href="celebritysingle.html">Luke Evans</a></h2>
                    <span>actor, mexico</span>
                    <p>
                      Luke George Evans was born in Pontypool, Wales, and grew
                      up in Aberbargoed, in the south of Wales. He is the son of
                      Yvonne (Lewis) and David Evans. He moved to Cardiff at the
                      age 17...
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="ranking">No.3</div>
              </div>
              <div class="col-md-12">
                <div class="ceb-item-style-2">
                  <img src="images/uploads/ceblist3.jpg" alt="" />
                  <div class="ceb-infor">
                    <h2>
                      <a href="celebritysingle.html">Scarlett Johansson</a>
                    </h2>
                    <span>actress, france</span>
                    <p>
                      Scarlett Ingrid Johansson was born in New York City. Her
                      mother, Melanie Sloan, is from a Jewish family from the
                      Bronx, and her father, Karsten Johansson, is a Danish-born
                      architect, from Copenhagen...
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="ranking">No.4</div>
              </div>
              <div class="col-md-12">
                <div class="ceb-item-style-2">
                  <img src="images/uploads/ceblist4.jpg" alt="" />
                  <div class="ceb-infor">
                    <h2><a href="celebritysingle.html">Emma Watson</a></h2>
                    <span>actress, uk</span>
                    <p>
                      Emma Charlotte Duerre Watson was born in Paris, France, to
                      English parents, Jacqueline Luesby and Chris Watson, both
                      lawyers. She moved to Oxfordshire when she was five...
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="ranking">No.5</div>
              </div>
              <div class="col-md-12">
                <div class="ceb-item-style-2">
                  <img src="images/uploads/ceblist5.jpg" alt="" />
                  <div class="ceb-infor">
                    <h2><a href="celebritysingle.html">Tom Hardy</a></h2>
                    <span>actor, italy </span>
                    <p>
                      Joan Crawford was born Lucille Fay LeSueur on March 23,
                      1905, in San Antonio, Texas, to Anna Belle (Johnson) and
                      Thomas E. LeSueur, a laundry laborer. By the time she was
                      born her parents had separated....
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="ranking">No.6</div>
              </div>
              <div class="col-md-12">
                <div class="ceb-item-style-2">
                  <img src="images/uploads/ceblist6.jpg" alt="" />
                  <div class="ceb-infor">
                    <h2><a href="celebritysingle.html">Joan Crawford</a></h2>
                    <span>director, sweden</span>
                    <p>
                      Joan Crawford was born Lucille Fay LeSueur on March 23,
                      1905, in San Antonio, Texas, to Anna Belle (Johnson) and
                      Thomas E. LeSueur, a laundry laborer. By the time she was
                      born her parents had separated....
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="ranking">No.7</div>
              </div>
              <div class="col-md-12">
                <div class="ceb-item-style-2">
                  <img src="images/uploads/ceblist7.jpg" alt="" />
                  <div class="ceb-infor">
                    <h2><a href="celebritysingle.html">Margot Robbie</a></h2>
                    <span>actress, chile</span>
                    <p>
                      Margot Robbie is an Australian actress born in Dalby,
                      Queensland, and raised on the Gold Coast, spending much of
                      her time at the farm belonging to her grandparents. Her
                      mother, Sarie Kessler, is a physiotherapist....
                    </p>
                  </div>
                </div>
              </div>
              <div class="col-md-12">
                <div class="ranking">No.8</div>
              </div>
              <div class="col-md-12">
                <div class="ceb-item-style-2">
                  <img src="images/uploads/ceblist8.jpg" alt="" />
                  <div class="ceb-infor">
                    <h2><a href="celebritysingle.html">Jason Momoa</a></h2>
                    <span>actor, usa</span>
                    <p>
                      Joseph Jason Namakaeha Momoa was born on August 1, 1979 in
                      Honolulu, Hawaii. He is the son of Coni (Lemke), a
                      photographer, and Joseph Momoa, a painter...
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end of celebrity list section-->
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.common-hero {
  /* background: url(https://images.pexels.com/photos/4982005/pexels-photo-4982005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2) */
  background: url(@/assets/images_choi/Views/choi/boxoffice/boxoffice03.jpeg)
    no-repeat;
  /* height: 598px; */
  width: 100%;
}
.ranking {
  margin-bottom: 1%;
  padding-left: 1%;
  background-color: rgb(127, 74, 161);
  font-family: "Dosis", sans-serif;
  font-size: 18px;
  color: #ffffff;
  font-weight: 700;
}
</style>
