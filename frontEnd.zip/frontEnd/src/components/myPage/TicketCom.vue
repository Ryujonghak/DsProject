<template>
  <div>
    <!--preloading-->
    <!-- <div id="preloader">
      <img class="logo" src="images/logo1.png" alt="" width="119" height="58" />
      <div id="status">
        <span></span>
        <span></span>
      </div>
    </div> -->

    <!-- 상단 페이지 제목 -->
    <div class="hero user-hero">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="hero-ct">
              <h1>{{ CurrentUser.name }}’s ticket</h1>
              <ul class="breadcumb">
                <li class="active">
                  <router-link to="/">Home</router-link>
                </li>
                <li><span class="ion-ios-arrow-right"></span>MY TICKET</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="page-single">
      <div class="container">
        <div class="row ipad-width">
          <!-- todo: 이부분 나브 다른 Mypage 컴포넌트들 공통 -->
          <!-- 공통 왼쪽 메뉴 시작 -->
          <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="user-information">
              <div class="user-img">
                <!-- src="images/uploads/user-img.png" -->
                <img
                  class="profileImg"
                  src="@/assets/images_choi/Views/choi/MovieDetail/user.png"
                  alt=""
                />
                <br />
              </div>
              <div class="user-fav">
                <ul>
                  <li class="active">
                    <router-link to="">프로필</router-link>
                  </li>
                  <!-- 프로필 로그인 정보 표시 시작-->
                  <li style="color: white">
                    <strong style="color: white">이름 </strong>
                    <label>{{ CurrentUser.name }}</label>
                  </li>
                  <li style="color: white">
                    <strong style="color: white">아이디 </strong>
                    <label>{{ CurrentUser.username }}</label>
                  </li>
                  <!-- 프로필 로그인 정보 표시 끝 -->
                </ul>
              </div>
              <div class="user-fav">
                <p>Account Details</p>
                <ul>
                  <li>
                    <router-link to="/mypage">내정보</router-link>
                  </li>
                  <li class="active">
                    <router-link to="/myticket">예매내역</router-link>
                  </li>
                  <li>
                    <router-link to="/mywish">찜한 영화</router-link>
                  </li>
                  <li>
                    <router-link to="/myqna">나의 문의내역</router-link>
                  </li>
                  <li>
                    <router-link to="/myprofile">개인정보 수정</router-link>
                  </li>
                </ul>
              </div>
              <div class="user-fav">
                <p>Others</p>
                <ul>
                  <!--                  <li><a href="#">Log out</a></li>-->
                  <li><a href="#" @click.prevent="logout">Log out</a></li>
                </ul>
              </div>
            </div>
          </div>
          <!-- 공통 왼쪽 메뉴 끝 -->

          <!-- 오른쪽 본문 내용 -->
          <div class="col-md-9 col-sm-12 col-xs-12">
            <div class="topbar-filter user">
              <p>나의 예매정보 <span>1 movies</span> in total</p>
              <select>
                <option value="range">-- 2022년 --</option>
                <option value="saab">-- 2021년 --</option>
              </select>
            </div>

            <!-- TODO: v-show 걸어야 함! -->
            <div v-show="unbooking">
              <h3>예매내역이 없습니다.</h3>
            </div>

            <!-- 예매내역 -->
            <!-- TODO: v-show 걸어야 함! -->
            <div v-show="!unbooking">
              <!-- <div> -->
              <div class="page-single userfav_list">
                <div class="container">
                  <div class="row ipad-width2">
                    <div class="col-md-9 col-sm-12 col-xs-12">
                      <div class="flex-wrap-movielist user-fav-list">
                        <!-- 예매한 영화 1 -->
                        <div class="movie-item-style-2">
                          <!-- todo) 이미지크기...  -->
                          <img :src="watchedMovie.posterURL" alt="poster" />
                          <div class="mv-item-infor">
                            <h6>
                              <!-- todo) 영화 상세보기 링크 변경 -->
                              <a href="moviesingle.html"
                                >{{ watchedMovie.movieNm }} <span>({{ watchedMovie.openDt }})</span></a
                              >
                            </h6>
                            <p class="rate">
                              <i class="ion-android-star"></i
                              ><span>{{ watchedMovie.rating }}</span> /5
                            </p>
                            <p>감독: {{ watchedMovie.directors }}</p>
                            <p class="describe">
                              상영시간: {{ watchedMovie.showTm }}분 <a>{{ watchedMovie.watchGradeNm}}</a>
                            </p>

                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                예매번호
                              </p>
                              <p class="col-xs-6">{{ watchedMovie.reservNo }}</p>
                            </div>
                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                상영날짜
                              </p>
                              <p class="col-xs-6">{{ watchedMovie.scheNo }}</p>
                            </div>
                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                관람극장
                              </p>
                              <p class="col-xs-6">{{ watchedMovie.theaterId }} {{ watchedMovie.screen }} {{ watchedMovie.startTime }}</p>
                            </div>
                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                관람좌석
                              </p>
                              <p class="col-xs-6">{{ watchedMovie.seatNo1 }} {{ watchedMovie.seatNo2 }} {{ watchedMovie.seatNo3 }} {{ watchedMovie.seatNo4 }} {{ watchedMovie.seatNo5 }}</p>
                            </div>
                            <p class="describe col-xs-12"></p>
                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                결제금액
                              </p>
                              <p class="col-xs-4">{{watchedMovie.cnt * watchedMovie.price}}원 ( {{ watchedMovie.cnt }}x{{ watchedMovie.price }} )</p>
                              <!-- TODO: 예매취소 버튼 - 클릭이벤트 -->
                              <div class="col-xs-4">
                                <a href="#" class="redbtn" @click="deleteTicket"
                                  >예매취소</a
                                >
                              </div>
                            </div>
                          </div>
                        </div>
                        <!-- 예매한 영화 2 -->
                        <div class="movie-item-style-2">
                          <!-- todo) 이미지크기...  -->
                          <img :src="watchedMovie.posterURL" alt="poster" />
                          <div class="mv-item-infor">
                            <h6>
                              <!-- todo) 영화 상세보기 링크 변경 -->
                              <a href="moviesingle.html"
                                >{{ watchedMovie.movieNm }} <span>({{ watchedMovie.openDt }})</span></a
                              >
                            </h6>
                            <p class="rate">
                              <i class="ion-android-star"></i
                              ><span>{{ watchedMovie.rating }}</span> /5
                            </p>
                            <p>감독: {{ watchedMovie.directors }}</p>
                            <p class="describe">
                              상영시간: {{ watchedMovie.showTm }}분 <a>{{ watchedMovie.watchGradeNm}}</a>
                            </p>

                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                예매번호
                              </p>
                              <p class="col-xs-6">{{ watchedMovie.reservNo }}</p>
                            </div>
                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                상영날짜
                              </p>
                              <p class="col-xs-6">{{ watchedMovie.scheNo }}</p>
                            </div>
                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                관람극장
                              </p>
                              <p class="col-xs-6">{{ watchedMovie.theaterId }} {{ watchedMovie.screen }} {{ watchedMovie.startTime }}</p>
                            </div>
                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                관람좌석
                              </p>
                              <p class="col-xs-6">{{ watchedMovie.seatNo1 }} {{ watchedMovie.seatNo2 }} {{ watchedMovie.seatNo3 }} {{ watchedMovie.seatNo4 }} {{ watchedMovie.seatNo5 }}</p>
                            </div>
                            <p class="describe col-xs-12"></p>
                            <div class="col-xs-12">
                              <p class="movie-detail-content col-xs-4">
                                결제금액
                              </p>
                              <p class="col-xs-4">{{watchedMovie.cnt * watchedMovie.price}}원 ( {{ watchedMovie.cnt }}x{{ watchedMovie.price }} )</p>
                              <!-- TODO: 예매취소 버튼 - 클릭이벤트 -->
                              <div class="col-xs-4">
                                <a href="#" class="redbtn" @click="deleteTicket"
                                  >예매취소</a
                                >
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- 예매내역 없을 때에만 공백 띄우기 -->
            <div v-show="unbooking">
              <div class="blank"></div>
            </div>

            <div>
              <!-- 본 영화 내역 -->
              <div class="topbar-filter user">
                <p>나의 관람한 영화 <span>1 movies</span> in total</p>
                <select>
                  <option value="range">-- 2022년 --</option>
                  <option value="saab">-- 2021년 --</option>
                </select>
              </div>
              <!-- 페이지  -->
              <div class="topbar-filter">
                <label>Movies per page:</label>
                <select>
                  <option value="range">20 Movies</option>
                  <option value="saab">10 Movies</option>
                </select>
                <div class="pagination2">
                  <span>Page 1 of 1:</span>
                  <a class="active" href="#">1</a>
                  <a href="#"><i class="ion-arrow-right-b"></i></a>
                </div>
              </div>
              <!-- 본 영화 -->
              <div class="row">
                <div class="col-xs-12 movie-item-style-2 userrate">
                  <!-- 포스터 -->
                  <div class="col-xs-2">
                    <img src="images/uploads/mv1.jpg" alt="" />
                  </div>
                  <!-- 영화정보 -->
                  <div class="col-xs-8">
                    <div class="mv-item-infor">
                      <h6>
                        <a href="#">{{ watchedMovie.movieNm }} <span>({{ watchedMovie.openDt }})</span></a>
                      </h6>
                      <!-- 별점 -->
                      <p class="rate">
                        <i class="ion-android-star"></i>
                        <span>{{ watchedMovie.rating }}</span> /5
                      </p>
                      <p>상영시간: {{ watchedMovie.showTm }}분 <a>{{ watchedMovie.watchGradeNm }}</a></p>
                      <span class="time sm">{{ watchedMovie.scheNo }}</span>
                      <br />
                      <span class="time sm">{{ watchedMovie.theaterId }} {{ watchedMovie.screen }} {{ watchedMovie.cnt }}명</span>
                      <br />
                      <span class="time sm-text">{{ watchedMovie.startTime }} ~ {{ watchedMovie.endTime }}</span>
                    </div>
                  </div>
                  <!-- 영화정보 끝 -->
                  <!-- 버튼 -->
                  <div class="col-xs-2">
                    <div class="movie-item-style-2">
                      <!-- FIXME: 버튼 클릭시 클릭이벤트-영화정보.title 넘겨줘야함 -->
                      <a href="/archive" class="redbtn" @click="goReview"
                        >관람평</a
                      >
                    </div>
                  </div>
                  <!-- 버튼 끝 -->
                </div>
              </div>
              <!-- 본 영화 -->
              <div class="row">
                <div class="col-xs-12 movie-item-style-2 userrate">
                  <!-- 포스터 -->
                  <div class="col-xs-2">
                    <img src="images/uploads/mv1.jpg" alt="" />
                  </div>
                  <!-- 영화정보 -->
                  <div class="col-xs-8">
                    <div class="mv-item-infor">
                      <h6>
                        <a href="#">{{ watchedMovie.movieNm }} <span>({{ watchedMovie.openDt }})</span></a>
                      </h6>
                      <!-- 별점 -->
                      <p class="rate">
                        <i class="ion-android-star"></i>
                        <span>{{ watchedMovie.rating }}</span> /5
                      </p>
                      <p>상영시간: {{ watchedMovie.showTm }}분 <a>{{ watchedMovie.watchGradeNm }}</a></p>
                      <span class="time sm">{{ watchedMovie.scheNo }}</span>
                      <br />
                      <span class="time sm">{{ watchedMovie.theaterId }} {{ watchedMovie.screen }} {{ watchedMovie.cnt }}명</span>
                      <br />
                      <span class="time sm-text">{{ watchedMovie.startTime }} ~ {{ watchedMovie.endTime }}</span>
                    </div>
                  </div>
                  <!-- 영화정보 끝 -->
                  <!-- 버튼 -->
                  <div class="col-xs-2">
                    <div class="movie-item-style-2">
                      <a href="#" class="redbtn" @click="goReview">관람평</a>
                    </div>
                  </div>
                  <!-- 버튼 끝 -->
                </div>
              </div>
              <!-- 본 영화 -->
              <div class="row">
                <div class="col-xs-12 movie-item-style-2 userrate">
                  <!-- 포스터 -->
                  <div class="col-xs-2">
                    <img src="images/uploads/mv1.jpg" alt="" />
                  </div>
                  <!-- 영화정보 -->
                  <div class="col-xs-8">
                    <div class="mv-item-infor">
                      <h6>
                        <a href="#">{{ watchedMovie.movieNm }} <span>({{ watchedMovie.openDt }})</span></a>
                      </h6>
                      <!-- 별점 -->
                      <p class="rate">
                        <i class="ion-android-star"></i>
                        <span>{{ watchedMovie.rating }}</span> /5
                      </p>
                      <p>상영시간: {{ watchedMovie.showTm }}분 <a>{{ watchedMovie.watchGradeNm }}</a></p>
                      <span class="time sm">{{ watchedMovie.scheNo }}</span>
                      <br />
                      <span class="time sm">{{ watchedMovie.theaterId }} {{ watchedMovie.screen }} {{ watchedMovie.cnt }}명</span>
                      <br />
                      <span class="time sm-text">{{ watchedMovie.startTime }} ~ {{ watchedMovie.endTime }}</span>
                    </div>
                  </div>
                  <!-- 영화정보 끝 -->
                  <!-- 버튼 -->
                  <div class="col-xs-2">
                    <div class="movie-item-style-2">
                      <a href="#" class="redbtn" @click="goReview">관람평</a>
                    </div>
                  </div>
                  <!-- 버튼 끝 -->
                </div>
              </div>
            </div>

            <!-- 2. 예매 내역 상세보기 -->
            <!-- <div class="page-single userfav_list">
              <div class="container">
                <div class="row ipad-width2">
                  <div class="col-md-9 col-sm-12 col-xs-12">
                    <div class="topbar-filter user">
                      <p>예매내역 상세보기<span>1 movies</span> in total</p>
                      <select>
                        <option value="range">-- 2022년 --</option>
                        <option value="saab">-- 2021년 --</option>
                      </select>
                    </div>

                    <div class="flex-wrap-movielist user-fav-list">
                      <div class="movie-item-style-2">
                        <img src="images/poster/영웅.jpg" alt="" />
                        <div class="mv-item-infor">
                          <h6>
                            <a href="moviesingle.html"
                              >영웅 <span>(2022)</span></a
                            >
                          </h6>
                          <p class="rate">
                            <i class="ion-android-star"></i><span>8.1</span> /10
                          </p>
                          <p>Director: 윤제균</p>
                          <p class="describe">
                            Run Time: 120분 <a>12세 관람가</a>
                          </p>

                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">
                              예매번호
                            </p>
                            <p class="col-xs-6">{{}}</p>
                          </div>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">
                              상영날짜
                            </p>
                            <p class="col-xs-6">{{}}</p>
                          </div>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">관람극장</p>
                            <p class="col-xs-6">{{}}</p>
                          </div>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">
                              관람좌석
                            </p>
                            <p class="col-xs-6">{{}}</p>
                          </div>
                          <p class="describe col-xs-12"></p>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">
                              결제금액
                            </p>
                            <p class="col-xs-4">{{}}</p>
                            <div class="col-xs-4">
                              <a href="#" class="redbtn">예매취소</a>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="movie-item-style-2">
                        <img src="images/poster/영웅.jpg" alt="" />
                        <div class="mv-item-infor">
                          <h6>
                            <a href="moviesingle.html"
                              >영웅 <span>(2022)</span></a
                            >
                          </h6>
                          <p class="rate">
                            <i class="ion-android-star"></i><span>8.1</span> /10
                          </p>
                          <p>Director: 윤제균</p>
                          <p class="describe">
                            Run Time: 120분 <a>12세 관람가</a>
                          </p>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">
                              예매번호
                            </p>
                            <p class="col-xs-6">{{}}</p>
                          </div>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">
                              상영날짜
                            </p>
                            <p class="col-xs-6">{{}}</p>
                          </div>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">관람극장</p>
                            <p class="col-xs-6">{{}}</p>
                          </div>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">
                              관람좌석
                            </p>
                            <p class="col-xs-6">{{}}</p>
                          </div>
                          <p class="describe col-xs-12"></p>
                          <div class="col-xs-12">
                            <p class="movie-detail-content col-xs-4">
                              결제금액
                            </p>
                            <p class="col-xs-4">{{}}</p>
                            <div class="col-xs-4">
                              <a href="#" class="redbtn">예매취소</a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div> -->
            <!-- 페이지 -->
            <ul class="pagination">
              <li class="icon-prev">
                <a href="#"><i class="ion-ios-arrow-left"></i></a>
              </li>
              <li class="active"><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">4</a></li>
              <li><a href="#">...</a></li>
              <li><a href="#">21</a></li>
              <li><a href="#">22</a></li>
              <li class="icon-next">
                <a href="#"><i class="ion-ios-arrow-right"></i></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
// import axios from "axios";   // 프로필이미지 업로드
import custom from "@/assets/js/custom";
import userService from "@/services/user.service";

export default {
  // data: () => ({
  //   images: "",
  // }),
  data() {
    return {
      CurrentUser: {
        email: "",
        password: "",
        username: "",
        phone: null,
        year: null, 
        month: null,
        day: null,
        name: "",
        answer: "", // 비번확인용 정답
      },
      message: "",
      // FIXME: 예매한 영화.. 작성중
      watchedMovie: {
        username: "", // 아이디
        paidDate: "", // 예매일자
        reservNo: "221228001", // 예매번호
        openDt: "2022", // 개봉년도
        movieNm: "눈의 여왕5: 스노우 프린세스와 미러랜드의 비밀", // 영화제목   -> title로 바꿔야하나?
        posterURL:
          "https://movie-phinf.pstatic.net/20221215_185/1671091761840XXpCR_JPEG/movie_image.jpg?type=m665_443_2", // 포스터 주소는 1개만 받으면 됩니다.",  // 영화포스터이미지
        directors: "제임스카메론", // 감독
        rating: 4.3, // 평점(관람객)
        starRating: 3.5, // 나중에 백엔드에서 평점 가져오기 (정수로 받아야 합니다,,)
        showTm: "192", // 상영시간
        watchGradeNm: "12세관람가", // 관람등급
        scheNo: "2022/12/28", // 상영스케쥴 - 날짜
        startTime: "18:00",    // 상영스케쥴 - 시간
        endTime: "21:12",    // 상영스케쥴 - 시간
        theaterId: "DS서면", // 관람극장 지점
        screen: "1관",  // 스크린번호
        seatNo1: "E03", // 좌석번호
        seatNo2: "E04", // 좌석번호
        seatNo3: "", // 좌석번호
        seatNo4: "", // 좌석번호
        seatNo5: "", // 좌석번호
        cnt: "2", // 예매수량
        price: "15000", // 금액
      },
      // TODO: 리뷰
      reviewMovie: {
        userStarRating: 2, // 사용자별점
        userReview: "", // 리뷰내용
      },
      // 예매 테이블 추가
      unbooking: false,
    };
  },
  methods: {
    // uploadImage: function () {
    //   let form = new FormData();
    //   let image = this.$refs["image"].files[0];
    //
    //   form.append("image", image);
    //
    //   axios
    //     .post("/upload", form, {
    //       header: { "Content-Type": "multipart/form-data" },
    //     })
    //     .then(({ data }) => {
    //       this.images = data;
    //     })
    //     .catch((err) => console.log(err));
    // },
    // clickInputTag: function () {
    //   this.$refs["image"].click();
    // },

    getUser(username) {
      // 종학이 백엔드 데이터 받는 함수
      username = this.$store.state.auth.user.username;
      // username = "forbob";
      console.log(username);
      userService
        .getUserUsername(username)
        .then((response) => {
          this.CurrentUser = {
            email: response.data.email,
            password: response.data.password,
            username: response.data.username,
            phone: response.data.phone,
            year: response.data.year,
            month: response.data.month,
            day: response.data.day,
            name: response.data.name,
            answer: response.data.answer,
          };
          console.log(this.CurrentUser);
          // console.log(response.data);
        })
        .catch((err) => console.log(err));
    },
    // FIXME: 클릭이벤트 - 리뷰작성하러가기 함수(영화제목 전달)
    goReview() {},
    // TODO: 클릭이벤트 - 티켓예매취소 함수
    deleteTicket() {},

    // 로그아웃 함수 -> 공통함수 호출
    logout() {
      // this.$store.dispatch("모듈명/함수명")
      this.$store.dispatch("auth/logout"); // 공통함수 logout 호출
      this.$router.push("/"); // 강제 홈페이지로 이동
    },
  },
  // created가 mounted보다 더 빨리 실행됨. 데이터 들어가기전에 떠야하는건 created에 넣어야 함
  mounted() {
    custom();
    this.getUser(); // 종학이 백엔드 데이터
  },
};
</script>

<style scoped>
.box-image {
  width: 55px;
  height: 70px;
}

.movie-item-style-2 {
  padding-top: 20px;
}

.blank {
  padding-top: 10%;
}

/* 배경이미지 : 아리걸로 통일 */
.user-hero {
  background: url(@/assets/images_jung/movie-theater02.jpg) no-repeat;
  /* height: 598px; */
  width: 100%;
}

/* 마이페이지-프로필 이미지크기 수정 */
.profileImg {
  -ms-interpolation-mode: bicubic;
  border: 0;
  /* height: auto; */
  max-height: 120px;
  /* max-width: 100%; */
  max-width: 120px;
  vertical-align: middle;
}
</style>
