<template>
  <div>
    <!--preloading-->
    <!-- <div id="preloader">
      <img class="logo" src="images/logo1.png" alt="" width="119" height="58" />
      <div id="status">
        <span></span>
        <span></span>
      </div>
    </div> -->

    <!-- 상단 페이지 제목 -->
    <div class="hero user-hero">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="hero-ct">
              <h1>{{ CurrentUser.name }}’s page</h1>
              <ul class="breadcumb">
                <li class="active">
                  <router-link to="/">Home</router-link>
                </li>
                <li><span class="ion-ios-arrow-right"></span>MY PAGE</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="page-single">
      <div class="container">
        <div class="row ipad-width">
          <!-- todo: 이부분 나브 다른 Mypage 컴포넌트들 공통 -->
          <!-- 공통 왼쪽 메뉴 시작 -->
          <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="user-information">
              <div class="user-img">
                <!-- src="images/uploads/user-img.png" -->
                <img
                  class="profileImg"
                  src="@/assets/images_choi/Views/choi/MovieDetail/user.png"
                  alt=""
                />
                <br />
              </div>
              <div class="user-fav">
                <ul>
                  <li class="active">
                    <router-link to="">프로필</router-link>
                  </li>
                  <!-- 프로필 로그인 정보 표시 시작-->
                  <li style="color: white">
                    <strong style="color: white">이름 </strong>
                    <label>{{ CurrentUser.name }}</label>
                  </li>
                  <li style="color: white">
                    <strong style="color: white">아이디 </strong>
                    <label>{{ CurrentUser.username }}</label>
                  </li>
                  <!-- 프로필 로그인 정보 표시 끝 -->
                </ul>
              </div>

              <div class="user-fav">
                <p>Account Details</p>
                <ul>
                  <li class="active">
                    <router-link to="/mypage">내정보</router-link>
                  </li>
                  <li>
                    <router-link to="/myticket">예매내역</router-link>
                  </li>
                  <li>
                    <router-link to="/mywish">찜한 영화</router-link>
                  </li>
                  <li>
                    <router-link to="/myqna">나의 문의내역</router-link>
                  </li>
                  <li>
                    <router-link to="/myprofile">개인정보 수정</router-link>
                  </li>
                </ul>
              </div>
              <div class="user-fav">
                <p>Others</p>
                <ul>
                  <!--                  <li><a href="#">Log out</a></li>-->
                  <li><a href="#" @click.prevent="logout">Log out</a></li>
                </ul>
              </div>
            </div>
          </div>
          <!-- 공통 왼쪽 메뉴 끝 -->

          <!-- 오른쪽 본문 내용 -->
          <div class="col-md-9 col-sm-12 col-xs-12">
            <!-- 프로필 -->
            <div class="col-xs-11 movie-item-style-2 userrate">
              <div class="row">
                <div class="col-xs-3 mv-user-review-item">
                  <!-- <div class="user-infor"> -->
                  <img
                    src="@/assets/images_choi/Views/choi/MovieDetail/user.png"
                    alt="user"
                  />
                  <div>
                    <!-- <p>{{ CurrentUser.id }} choichoi</p> -->
                    <h3>{{ CurrentUser.name }} 님</h3>
                    <h3>환영해요!</h3>
                    <!-- </div> -->
                  </div>
                </div>

                <div class="col-xs-6 mv-user-review-item">
                  <!-- <div class="user-infor"> -->
                  <h6>즐겨찾는 영화관</h6>
                  <div>
                    <table>
                      <tr>
                        <td>
                          <h6><a href="#"></a></h6>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          <div class="mv-item-infor">
                            <h6><a href="#">DS 서면</a></h6>
                          </div>
                        </td>
                        <td>
                          <div class="mv-item-infor">
                            <h6><a href="#">DS 해운대</a></h6>
                          </div>
                        </td>
                        <td>
                          <div class="mv-item-infor">
                            <h6><a href="#">영화관3</a></h6>
                          </div>
                        </td>
                      </tr>
                    </table>
                  </div>
                </div>

                <div class="col-xs-2 mv-user-review-item">
                  <h6>나의 등급</h6>
                  <div>
                    <img src="@/assets/images_jung/welcome.png" alt="" />
                  </div>
                </div>
              </div>
            </div>
            <!-- 즐겨찾는 영화관 -->

            <!-- 아카이브 -->
            <div class="container">
              <div class="row ipad-width2">
                <div class="col-md-8 col-sm-12 col-xs-12">
                  <!-- 아카이브 나브 -->
                  <div class="topbar-filter">
                    <router-link to ="/archive"
                      ><p>나의 아카이브 <span>8</span> in total</p></router-link
                    >
                    <a href="userfavoritegrid.html" class="grid"
                      ><i class="ion-grid"></i
                    ></a>
                  </div>
                  <!-- 나의 아카이브 내용 시작 -->
                  <!-- TODO: 본 영화 정보 받아오기 :  -->
                  <div class="flex-wrap-movielist">
                    <!-- 상영작 1 -->
                    <div class="movie-item-style-2 movie-item-style-1">
                      <!-- todo) 포스터 사이즈를 통일해야.. 예쁘게 나올듯 -->
                      <img :src="watchedMovie.posterURL" alt="poster" />
                      <!-- 영화에 마우스 올리면 나오는 관람정보 -->
                      <div class="hvr-inner">
                        <div class="movieTitle">
                          <h6>
                            <router-link to="/movieDetail">
                              {{ watchedMovie.movieNm }}
                              <span
                                >({{ watchedMovie.openDt }})</span
                              ></router-link
                            >
                          </h6>
                        </div>
                        <p>
                          {{ watchedMovie.scheNo }} <br />
                          상영시간: {{ watchedMovie.showTm }}분 <br />
                          감독: {{ watchedMovie.directors }}
                        </p>
                        <!-- 리뷰테이블에서 사용자 평점 가져오기 -->
                        <p class="time sm-text">
                          나의 별점
                          <!-- 별점 v-for -->
                          <i class="ion-android-star"></i
                          ><span>{{ reviewMovie.userStarRating }}</span>
                        </p>
                        <!-- TODO: 버튼 클릭시 클릭이벤트-영화정보.movieNm 넘겨줘야함 -->
                        <router-link to="/archive" @click="goReview"
                          >나의 리뷰 작성하기</router-link
                        >
                        <!-- <h6>Best Musical movie</h6> -->
                      </div>
                      <!-- 영화 라벨 -->
                      <div class="mv-item-infor">
                        <div class="movieTitle-2">
                          <h6>
                            <a href="/movieDetail">{{
                              watchedMovie.movieNm
                            }}</a>
                          </h6>
                        </div>
                        <p class="rate">
                          <i class="ion-android-star"></i
                          ><span>{{ watchedMovie.rating }}</span> /5
                        </p>
                      </div>
                    </div>
                    <!-- 상영작 2 -->
                    <div class="movie-item-style-2 movie-item-style-1">
                      <!-- todo) 포스터 사이즈를 통일해야.. 예쁘게 나올듯 -->
                      <img :src="watchedMovie.posterURL" alt="poster" />
                      <!-- 영화에 마우스 올리면 나오는 관람정보 -->
                      <div class="hvr-inner">
                        <div class="movieTitle">
                          <h6>
                            <router-link to="/movieDetail">
                              {{ watchedMovie.movieNm }}
                              <span
                                >({{ watchedMovie.openDt }})</span
                              ></router-link
                            >
                          </h6>
                        </div>
                        <p>
                          {{ watchedMovie.scheNo }} <br />
                          상영시간: {{ watchedMovie.showTm }}분 <br />
                          감독: {{ watchedMovie.directors }}
                        </p>
                        <!-- 리뷰테이블에서 사용자 평점 가져오기 -->
                        <p class="time sm-text">
                          나의 별점
                          <!-- 별점 v-for -->
                          <i class="ion-android-star"></i
                          ><span>{{ reviewMovie.userStarRating }}</span>
                        </p>
                        <!-- TODO: 버튼 클릭시 클릭이벤트-영화정보.movieNm 넘겨줘야함 -->
                        <router-link to="/archive" @click="goReview"
                          >나의 리뷰 작성하기</router-link
                        >
                        <!-- <h6>Best Musical movie</h6> -->
                      </div>
                      <!-- 영화 라벨 -->
                      <div class="mv-item-infor">
                        <div class="movieTitle-2">
                          <h6>
                            <a href="/movieDetail">{{
                              watchedMovie.movieNm
                            }}</a>
                          </h6>
                        </div>
                        <p class="rate">
                          <i class="ion-android-star"></i
                          ><span>{{ watchedMovie.rating }}</span> /5
                        </p>
                      </div>
                    </div>
                    <!-- 상영작 3 -->
                    <div class="movie-item-style-2 movie-item-style-1">
                      <!-- todo) 포스터 사이즈를 통일해야.. 예쁘게 나올듯 -->
                      <img :src="watchedMovie.posterURL" alt="poster" />
                      <!-- 영화에 마우스 올리면 나오는 관람정보 -->
                      <div class="hvr-inner">
                        <div class="movieTitle">
                          <h6>
                            <router-link to="/movieDetail">
                              {{ watchedMovie.movieNm }}
                              <span
                                >({{ watchedMovie.openDt }})</span
                              ></router-link
                            >
                          </h6>
                        </div>
                        <p>
                          {{ watchedMovie.scheNo }} <br />
                          상영시간: {{ watchedMovie.showTm }}분 <br />
                          감독: {{ watchedMovie.directors }}
                        </p>
                        <!-- 리뷰테이블에서 사용자 평점 가져오기 -->
                        <p class="time sm-text">
                          나의 별점
                          <!-- 별점 v-for -->
                          <i class="ion-android-star"></i
                          ><span>{{ reviewMovie.userStarRating }}</span>
                        </p>
                        <!-- TODO: 버튼 클릭시 클릭이벤트-영화정보.movieNm 넘겨줘야함 -->
                        <router-link to="/archive" @click="goReview"
                          >나의 리뷰 작성하기</router-link
                        >
                        <!-- <h6>Best Musical movie</h6> -->
                      </div>
                      <!-- 영화 라벨 -->
                      <div class="mv-item-infor">
                        <div class="movieTitle-2">
                          <h6>
                            <a href="/movieDetail">{{
                              watchedMovie.movieNm
                            }}</a>
                          </h6>
                        </div>
                        <p class="rate">
                          <i class="ion-android-star"></i
                          ><span>{{ watchedMovie.rating }}</span> /5
                        </p>
                      </div>
                    </div>
                    <!-- 상영작 4 -->
                    <div class="movie-item-style-2 movie-item-style-1">
                      <!-- todo) 포스터 사이즈를 통일해야.. 예쁘게 나올듯 -->
                      <img :src="watchedMovie.posterURL" alt="poster" />
                      <!-- 영화에 마우스 올리면 나오는 관람정보 -->
                      <div class="hvr-inner">
                        <div class="movieTitle">
                          <h6>
                            <router-link to="/movieDetail">
                              {{ watchedMovie.movieNm }}
                              <span
                                >({{ watchedMovie.openDt }})</span
                              ></router-link
                            >
                          </h6>
                        </div>
                        <p>
                          {{ watchedMovie.scheNo }} <br />
                          상영시간: {{ watchedMovie.showTm }}분 <br />
                          감독: {{ watchedMovie.directors }}
                        </p>
                        <!-- 리뷰테이블에서 사용자 평점 가져오기 -->
                        <p class="time sm-text">
                          나의 별점
                          <!-- 별점 v-for -->
                          <i class="ion-android-star"></i
                          ><span>{{ reviewMovie.userStarRating }}</span>
                        </p>
                        <!-- TODO: 버튼 클릭시 클릭이벤트-영화정보.movieNm 넘겨줘야함 -->
                        <router-link to="/archive" @click="goReview"
                          >나의 리뷰 작성하기</router-link
                        >
                        <!-- <h6>Best Musical movie</h6> -->
                      </div>
                      <!-- 영화 라벨 -->
                      <div class="mv-item-infor">
                        <div class="movieTitle-2">
                          <h6>
                            <a href="/movieDetail">{{
                              watchedMovie.movieNm
                            }}</a>
                          </h6>
                        </div>
                        <p class="rate">
                          <i class="ion-android-star"></i
                          ><span>{{ watchedMovie.rating }}</span> /5
                        </p>
                      </div>
                    </div>
                    <!-- 상영작 5 -->
                    <div class="movie-item-style-2 movie-item-style-1">
                      <img src="images/uploads/mv1.jpg" alt="" />
                      <!-- 영화에 마우스 올리면 나오는 상세페이지 이동 버튼 -->
                      <div class="hvr-inner">
                        <h6>
                          <a href="#">영웅 <span>(2022)</span></a>
                        </h6>
                        <p>
                          Run Time: {{}} 2h 21’ <br />
                          Director: {{}} dd <br />
                          Watched: 2022/12/22
                        </p>
                        <p class="time sm-text">your reviews:</p>
                        <h6>Best Musical movie in my opinion</h6>
                      </div>
                      <!-- 제목 -->
                      <div class="mv-item-infor">
                        <h6><a href="#">영웅</a></h6>
                        <p class="rate">
                          <i class="ion-android-star"></i><span>8.1</span> /10
                          <!-- <i class="ion-android-star"></i><span>{{ movie.userRating }}</span> /10 -->
                        </p>
                      </div>
                    </div>
                    <!-- 상영작 6 -->
                    <div class="movie-item-style-2 movie-item-style-1">
                      <img src="images/uploads/mv1.jpg" alt="" />
                      <!-- 영화에 마우스 올리면 나오는 상세페이지 이동 버튼 -->
                      <div class="hvr-inner">
                        <h6>
                          <a href="#">영웅 <span>(2022)</span></a>
                        </h6>
                        <p>
                          Run Time: {{}} 2h 21’ <br />
                          Director: {{}} dd <br />
                          Watched: 2022/12/22
                        </p>
                        <p class="time sm-text">your reviews:</p>
                        <h6>Best Musical movie in my opinion</h6>
                      </div>
                      <!-- 제목 -->
                      <div class="mv-item-infor">
                        <h6><a href="#">영웅</a></h6>
                        <p class="rate">
                          <i class="ion-android-star"></i><span>8.1</span> /10
                          <!-- <i class="ion-android-star"></i><span>{{ movie.userRating }}</span> /10 -->
                        </p>
                      </div>
                    </div>
                    <!-- 상영작 7 -->
                    <div class="movie-item-style-2 movie-item-style-1">
                      <img src="images/uploads/mv1.jpg" alt="" />
                      <!-- 영화에 마우스 올리면 나오는 상세페이지 이동 버튼 -->
                      <div class="hvr-inner">
                        <h6>
                          <a href="#">영웅 <span>(2022)</span></a>
                        </h6>
                        <p>
                          Run Time: {{}} 2h 21’ <br />
                          Director: {{}} dd <br />
                          Watched: 2022/12/22
                        </p>
                        <p class="time sm-text">your reviews:</p>
                        <h6>Best Musical movie in my opinion</h6>
                      </div>
                      <!-- 제목 -->
                      <div class="mv-item-infor">
                        <h6><a href="#">영웅</a></h6>
                        <p class="rate">
                          <i class="ion-android-star"></i><span>8.1</span> /10
                          <!-- <i class="ion-android-star"></i><span>{{ movie.userRating }}</span> /10 -->
                        </p>
                      </div>
                    </div>
                    <!-- 상영작 8 -->
                    <div class="movie-item-style-2 movie-item-style-1">
                      <img src="images/uploads/mv1.jpg" alt="" />
                      <!-- 영화에 마우스 올리면 나오는 상세페이지 이동 버튼 -->
                      <div class="hvr-inner">
                        <h6>
                          <a href="#">영웅 <span>(2022)</span></a>
                        </h6>
                        <p>
                          Run Time: {{}} 2h 21’ <br />
                          Director: {{}} dd <br />
                          Watched: 2022/12/22
                        </p>
                        <p class="time sm-text">your reviews:</p>
                        <h6>Best Musical movie in my opinion</h6>
                      </div>
                      <!-- 제목 -->
                      <div class="mv-item-infor">
                        <h6><a href="#">영웅</a></h6>
                        <p class="rate">
                          <i class="ion-android-star"></i><span>8.1</span> /10
                          <!-- <i class="ion-android-star"></i><span>{{ movie.userRating }}</span> /10 -->
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/* eslint-disable */

// import axios from "axios";   // 프로필이미지 업로드
import custom from "@/assets/js/custom";
import userService from "@/services/user.service";

export default {
  // data: () => ({
  //   images: "",
  // }),
  data() {
    return {
      CurrentUser: {
        email: "",
        password: "",
        username: "",
        phone: null,
        year: null, 
        month: null,
        day: null,
        name: "",
        answer: "", // 비번확인용 정답
      },
      message: "",

      // FIXME: 예매한 영화.. 작성중
      watchedMovie: {
        username: "", // 아이디
        paidDate: "", // 예매일자
        reservNo: "", // 예매번호
        openDt: "2022", // 개봉년도
        movieNm: "눈의 여왕5: 스노우 프린세스와 미러랜드의 비밀", // 영화제목   -> title로 바꿔야하나?
        posterURL:
          "https://movie-phinf.pstatic.net/20221215_185/1671091761840XXpCR_JPEG/movie_image.jpg?type=m665_443_2", // 포스터 주소는 1개만 받으면 됩니다.",  // 영화포스터이미지
        directors: "제임스카메론", // 감독 (최대7자)
        rating: 4.3, // 평점(관람객)
        starRating: 3.5, // 나중에 백엔드에서 평점 가져오기 (정수로 받아야 합니다,,)
        showTm: "192", // 상영시간
        watchGradeNm: "12세관람가", // 관람등급
        scheNo: "2022/12/28", // 상영스케쥴
        seatNo: "I3", // 좌석번호
        cnt: "1", // 예매수량
        price: "15000", // 금액
      },
      // TODO: 리뷰
      reviewMovie: {
        userStarRating: 2, // 사용자별점
        userReview: "", // 리뷰내용
      },
    };
  },
  methods: {
    // uploadImage: function () {
    //   let form = new FormData();
    //   let image = this.$refs["image"].files[0];
    //
    //   form.append("image", image);
    //
    //   axios
    //     .post("/upload", form, {
    //       header: { "Content-Type": "multipart/form-data" },
    //     })
    //     .then(({ data }) => {
    //       this.images = data;
    //     })
    //     .catch((err) => console.log(err));
    // },
    // clickInputTag: function () {
    //   this.$refs["image"].click();
    // },

    getUser(username) {
      // 종학이 백엔드 데이터 받는 함수
      username = this.$store.state.auth.user.username;
      // username = "forbob";
      console.log(username);
      userService
        .getUserUsername(username)
        .then((response) => {
          this.CurrentUser = {
            email: response.data.email,
            password: response.data.password,
            username: response.data.username,
            phone: response.data.phone,
            year: response.data.year,
            month: response.data.month,
            day: response.data.day,
            name: response.data.name,
            answer: response.data.answer,
          };
          console.log(this.CurrentUser);
          // console.log(response.data);
        })
        .catch((err) => console.log(err));
    },

    // 로그아웃 함수 -> 공통함수 호출
    logout() {
      // this.$store.dispatch("모듈명/함수명")
      this.$store.dispatch("auth/logout"); // 공통함수 logout 호출
      this.$router.push("/"); // 강제 홈페이지로 이동
    },
    // TODO: 클릭이벤트 - 리뷰작성하러가기 함수(영화제목 전달)
    goReview() {
      // 영화 제목 정보 보내야 함
      // movieNm = this.movieNm;
    },
  },
  mounted() {
    custom();
    this.getUser(); // 종학이 백엔드 데이터
  },
};
</script>

<style scoped>
.box-image {
  width: 55px;
  height: 70px;
}

.movie-detail-content {
  padding-left: 0;
}

.movie-detail-content-bottom {
  padding-bottom: 10px;
}

/* 영화제목 div 크기지정 */
.movieTitle {
  height: 50px;
}
.movieTitle-2 {
  height: 35px;
}

/* 배경이미지 : 아리걸로 통일 */
.user-hero {
  background: url(@/assets/images_jung/movie-theater02.jpg) no-repeat;
  /* height: 598px; */
  width: 100%;
}

/* 마이페이지-프로필 이미지크기 수정 */
.profileImg {
  -ms-interpolation-mode: bicubic;
  border: 0;
  /* height: auto; */
  max-height: 120px;
  /* max-width: 100%; */
  max-width: 120px;
  vertical-align: middle;
}
</style>

