<template>
<div>
    <div class="hero user-hero">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="hero-ct">
              <h1>ADMIN PAGE</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="page-single">
      <div class="container">
        <div class="row ipad-width2">
          <!-- <!— 왼쪽 메뉴바 시작 —> -->
          <div class="col-md-3 col-sm-12 col-xs-12">
            <div class="user-information">
              <div class="user-fav">
                <p>관리자 목록</p>
                <ul>
                  <li><router-link to="/userInfoAdmin">회원관리</router-link></li>
                  <li >
                    <a href="#"></a>
                    <a
                      class="btn btn-default dropdown-toggle"
                      data-toggle="dropdown"
                      @click="boardclick"
                    >
                      게시판관리
                      <i class="fa fa-angle-down" aria-hidden="true"></i>
                    </a>
                    <ul class="dropdown" v-show="board">
                      <li><router-link to="/board-admin">공지사항 관리</router-link></li>
                      <li>
                        <router-link to="/movie-admin">영화 관리</router-link>
                      </li>
                      <li><router-link to="/review-admin">리뷰관리</router-link></li>
                  <li><router-link to="/qna-admin">QnA 답변관리</router-link></li>
                    </ul>
                  </li>
                  <li class="active"><router-link to="/payment-admin">예매 내역</router-link></li>
                </ul>
              </div>
              <div class="user-fav">
                <ul>
                    <li><a href="#" @click="logout">Log out</a></li>
                </ul>
              </div>
            </div>
          </div>
          <!-- <!— 왼쪽 메뉴바 끝 —> -->

          <div class="col-md-9 col-sm-12 col-xs-12">
            <div style="margin-bottom:2%;">
              <h3 style="color: aliceblue">예매 내역</h3>
            </div>

            <!-- 전체정렬 -->
            <!--리뷰 테이블 관리 시작 (list)  -->
            <div class="movie-item-style-2 userrate">
              <div class="mv-item-infor">
                <table class="notice_table">
                  <colgroup>
                    <col style="width: 5%" />
                    <col style="width: 10%" />
                    <col style="width: 10%" />
                    <col style="width: 10%" />
                    <col style="width: 10%" />
                    <col style="width: 10%" />
                    <col style="width: 10%" />
                    <col style="width: 5%" />
                    <col style="width: 10%" />
                  </colgroup>
                  <thead>
                    <tr>
                      <th scope="col">NO</th>
                      <th scope="col">username</th>
                      <th scope="col">지점</th>
                      <th scope="col">상영관</th>
                      <th scope="col">영화시간</th>
                      <th scope="col">영화명</th>
                      <th scope="col">좌석번호</th>
                      <th scope="col">수량</th>
                      <th scope="col">결제가격</th>
                      <!-- <th scope="col">결제시간</th> -->
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="(data, index) in Payment" v-bind:key="index">
                      <td>{{ data.reservno }}</td>
                      <td>{{ data.username }}</td>
                      <td>{{ data.scheduleno }}</td>
                      <td>{{ data.SCREEN }}</td>
                      <td>{{ data.starttime }}</td>
                      <td>{{ data.movienm }}</td>
                      <td>{{ data.seatNo }}</td>
                      <td>{{ data.count }}</td>
                      <td>{{ data.price }}</td>
                      <!-- <td>{{ data.paidDate }}</td> -->
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <!--리뷰 테이블 관리 테이블 끝  -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
    data() {
        return {
            board: false,
        }
    },
    methods: {
        logout() {
      this.$store.dispatch("auth/logout"); 
      this.$router.push("/");
    },
          //왼쪽 메뉴바 slide효과
    boardclick() {
      this.board = !this.board;
    },
    },

}
</script>

<style lang="scss" scoped>
th {
  color: aliceblue;
  border: 1px solid aliceblue;
  //border-right: 2px solid aliceblue;
  text-align: center;
}
td {
  color: aliceblue;
  border-bottom: 1px solid aliceblue;
  text-align: center;
  vertical-align: middle !important;
}
.deletebtn {
  background: #dd003f;
  color: aliceblue;
  border-radius: 3px !important;
  box-shadow: none !important;
  width: 50%;
}
button {
  border: none !important;
}
button:active {
  outline: none !important;
  box-shadow: none !important;
}

.user-hero {
  height: 385px;
  // background: url("../images/uploads/user-hero-bg.jpg") no-repeat;
  background: url("../../assets/images_kang/Components/common/Navcom/back-img-test9.png") no-repeat;
}
</style>
